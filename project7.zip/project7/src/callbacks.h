#include <gtk/gtk.h>


void
on_button1n_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button3n_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button5n_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button4n_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button2n__clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button6n_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button7n_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button8n_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button9n_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);
void
on_button10n_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button11n_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_treeview2n_row_activated          ( GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button15n_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data) ;

void
on_button14n_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data) ;

void
on_button16n_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data) ;

void
on_button17n_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data) ;

void
on_treeview1n_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button18n_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button19n_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button20n_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_combobox4n_changed                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button21n_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data) ;

void
on_button22n_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data) ;

void
on_button23n_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button24n_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button27n_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button25n_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button26n_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);
